<!DOCTYPE html>
<!-- Created By CodingLab - www.codinglabweb.com -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <!---<title> Responsive Registration Form | CodingLab </title>--->
    <link rel="stylesheet" href="css/style.css">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
  <div class="container">
    <div class="title">Welcome!</div>
    <div class="content">
     <p>
         welcome <?php echo $name?> !
     </p>
     </br>
     <p>
         enjoy staring at nothing
     </p>
    </div>
  </div>

</body>
</html>